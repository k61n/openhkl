.. cmake-module:: ../../Modules/FindOpenThreads.cmake
